-- ============================================================
--  BASIC FILTERS — Q1 to Q4, Q9, Q10
--  Topics: WHERE, LIKE, AND, OR, IS NULL, IN, ORDER BY
-- ============================================================

USE sakila;

-- Q1: LIKE + AND
SELECT * FROM customer
WHERE first_name LIKE 'J%'
  AND active = 1;

-- Q2: LIKE with OR
SELECT * FROM film
WHERE title LIKE '%ACTION%'
   OR description LIKE '%WAR%';

-- Q3: != and trailing wildcard
SELECT * FROM customer
WHERE last_name != 'SMITH'
  AND first_name LIKE '%a';

-- Q4: IS NOT NULL
SELECT * FROM film
WHERE rental_rate > 3.0
  AND replacement_cost IS NOT NULL;

-- Q9: IS NULL + OR
SELECT * FROM customer
WHERE email IS NULL
   OR email LIKE '%.org';

-- Q10: IN + ORDER BY DESC
SELECT * FROM film
WHERE rating IN ('PG', 'G')
ORDER BY rental_rate DESC;
