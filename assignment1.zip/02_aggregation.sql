-- ============================================================
--  AGGREGATION — Q5, Q6, Q7, Q8, Q11
--  Topics: COUNT, SUM, AVG, GROUP BY, HAVING, DISTINCT
-- ============================================================

USE sakila;

-- Q5: GROUP BY + COUNT
SELECT store_id, COUNT(*) AS active_customer_count
FROM customer
WHERE active = 1
GROUP BY store_id;

-- Q6: DISTINCT
SELECT DISTINCT rating FROM film;

-- Q7: GROUP BY + HAVING with AVG
SELECT rental_duration, COUNT(*) AS film_count, AVG(length) AS avg_length
FROM film
GROUP BY rental_duration
HAVING AVG(length) > 100;

-- Q8: DATE() + SUM + HAVING
SELECT DATE(payment_date) AS pay_date,
       SUM(amount)        AS total_amount,
       COUNT(*)           AS payment_count
FROM payment
GROUP BY DATE(payment_date)
HAVING COUNT(*) > 100;

-- Q11: WHERE + GROUP BY + HAVING
SELECT length, COUNT(*) AS film_count
FROM film
WHERE title LIKE 'T%'
GROUP BY length
HAVING COUNT(*) > 5;
