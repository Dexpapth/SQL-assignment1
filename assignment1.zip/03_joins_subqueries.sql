-- ============================================================
--  JOINS & SUBQUERIES — Q12, Q13, Q14, Q15
--  Topics: JOIN, LEFT JOIN, LIMIT, Subquery
-- ============================================================

USE sakila;

-- Q12: JOIN + GROUP BY + HAVING
SELECT a.actor_id, a.first_name, a.last_name, COUNT(*) AS film_count
FROM actor a
JOIN film_actor fa ON a.actor_id = fa.actor_id
GROUP BY a.actor_id, a.first_name, a.last_name
HAVING COUNT(*) > 10;

-- Q13: Multi-column ORDER BY + LIMIT
SELECT title, rental_rate, length
FROM film
ORDER BY rental_rate DESC, length DESC
LIMIT 5;

-- Q14: LEFT JOIN + COUNT
SELECT c.customer_id, c.first_name, c.last_name,
       COUNT(r.rental_id) AS total_rentals
FROM customer c
LEFT JOIN rental r ON c.customer_id = r.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_rentals DESC;

-- Q15: Chained LEFT JOIN + IS NULL
SELECT f.film_id, f.title
FROM film f
LEFT JOIN inventory i ON f.film_id = i.film_id
LEFT JOIN rental r    ON i.inventory_id = r.inventory_id
WHERE r.rental_id IS NULL;
