-- ============================================================
--  SQL PRACTICE QUESTIONS — SAKILA DATABASE
--  All 15 Questions with Answers & Explanations
-- ============================================================

USE sakila;

-- ============================================================
-- Q1. Get all customers whose first name starts with 'J'
--     and who are active.
-- ============================================================
-- LIKE 'J%' matches any name starting with J (John, Jane, etc.)
-- active = 1 means the customer is currently active
-- AND means both conditions must be true

SELECT *
FROM customer
WHERE first_name LIKE 'J%'
  AND active = 1;

-- ============================================================
-- Q2. Find all films where the title contains 'ACTION'
--     or the description contains 'WAR'.
-- ============================================================
-- %ACTION% means ACTION can appear anywhere in the title
-- OR means either condition is enough to include the row

SELECT *
FROM film
WHERE title LIKE '%ACTION%'
   OR description LIKE '%WAR%';

-- ============================================================
-- Q3. List customers whose last name is NOT 'SMITH'
--     and whose first name ends with 'a'.
-- ============================================================
-- != means not equal, excludes all SMITH records
-- LIKE '%a' matches names ending with lowercase a (Maria, Anna)

SELECT *
FROM customer
WHERE last_name != 'SMITH'
  AND first_name LIKE '%a';

-- ============================================================
-- Q4. Get all films where rental rate > 3.0
--     and replacement cost is not null.
-- ============================================================
-- > 3.0 is a standard numeric comparison
-- IS NOT NULL checks the column actually has a value
-- NEVER use = NULL — it always returns nothing in SQL

SELECT *
FROM film
WHERE rental_rate > 3.0
  AND replacement_cost IS NOT NULL;

-- ============================================================
-- Q5. Count how many customers exist in each store
--     who have active status = 1.
-- ============================================================
-- WHERE active = 1 filters rows BEFORE grouping
-- GROUP BY store_id splits results by store
-- COUNT(*) counts how many rows are in each group

SELECT   store_id,
         COUNT(*) AS active_customer_count
FROM     customer
WHERE    active = 1
GROUP BY store_id;

-- ============================================================
-- Q6. Show distinct film ratings in the film table.
-- ============================================================
-- DISTINCT removes duplicate values from the output
-- Without it, rating would repeat for every single film row
-- Result will be: G, PG, PG-13, R, NC-17

SELECT DISTINCT rating
FROM film;

-- ============================================================
-- Q7. Find number of films for each rental duration
--     where the average length is more than 100 minutes.
-- ============================================================
-- GROUP BY rental_duration groups films by rental days
-- HAVING filters AFTER grouping — use it with AVG, COUNT, SUM
-- You CANNOT use WHERE AVG(length) > 100 — that is a syntax error

SELECT   rental_duration,
         COUNT(*)      AS film_count,
         AVG(length)   AS avg_length
FROM     film
GROUP BY rental_duration
HAVING   AVG(length) > 100;

-- ============================================================
-- Q8. List payment dates and total amount per date —
--     only include days where more than 100 payments were made.
-- ============================================================
-- DATE() strips the time from datetime, keeps only the date
-- SUM(amount) totals all payments for that day
-- HAVING COUNT(*) > 100 removes low-volume days

SELECT   DATE(payment_date)  AS pay_date,
         SUM(amount)         AS total_amount,
         COUNT(*)            AS payment_count
FROM     payment
GROUP BY DATE(payment_date)
HAVING   COUNT(*) > 100;

-- ============================================================
-- Q9. Find customers whose email is null
--     or ends with '.org'.
-- ============================================================
-- IS NULL checks for missing/empty email values
-- LIKE '%.org' matches emails ending in .org
-- OR means either condition satisfies the row

SELECT *
FROM customer
WHERE email IS NULL
   OR email LIKE '%.org';

-- ============================================================
-- Q10. List all films with rating 'PG' or 'G',
--      ordered by rental rate descending.
-- ============================================================
-- IN ('PG', 'G') is cleaner than writing OR twice
-- ORDER BY rental_rate DESC puts most expensive first
-- Default ORDER BY is ASC (lowest first)

SELECT *
FROM   film
WHERE  rating IN ('PG', 'G')
ORDER BY rental_rate DESC;

-- ============================================================
-- Q11. Count films per length where title starts with 'T'
--      and the count is more than 5.
-- ============================================================
-- WHERE runs first — filters only T-starting films
-- GROUP BY length groups those filtered films
-- HAVING COUNT(*) > 5 keeps only lengths with 5+ films

SELECT   length,
         COUNT(*) AS film_count
FROM     film
WHERE    title LIKE 'T%'
GROUP BY length
HAVING   COUNT(*) > 5;

-- ============================================================
-- Q12. List all actors who have appeared in more than 10 films.
-- ============================================================
-- film_actor is the junction table linking actors to films
-- JOIN connects actor names with the film_actor rows
-- GROUP BY actor, then HAVING filters by film count

SELECT   a.actor_id,
         a.first_name,
         a.last_name,
         COUNT(*) AS film_count
FROM     actor a
JOIN     film_actor fa ON a.actor_id = fa.actor_id
GROUP BY a.actor_id, a.first_name, a.last_name
HAVING   COUNT(*) > 10;

-- ============================================================
-- Q13. Find top 5 films with highest rental rates
--      and longest lengths. Order by rental rate first,
--      then length.
-- ============================================================
-- Multi-column ORDER BY: rental_rate first, length as tiebreaker
-- Both DESC means highest values come first
-- LIMIT 5 returns only the top 5 rows

SELECT   title,
         rental_rate,
         length
FROM     film
ORDER BY rental_rate DESC, length DESC
LIMIT 5;

-- ============================================================
-- Q14. Show all customers with total rentals made,
--      ordered from most to least.
-- ============================================================
-- LEFT JOIN keeps all customers even with zero rentals
-- COUNT(r.rental_id) counts only real rental rows (not NULLs)
-- So customers with no rentals get 0 — not excluded

SELECT   c.customer_id,
         c.first_name,
         c.last_name,
         COUNT(r.rental_id) AS total_rentals
FROM     customer c
LEFT JOIN rental r ON c.customer_id = r.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_rentals DESC;

-- ============================================================
-- Q15. List film titles that have NEVER been rented.
-- ============================================================
-- Path to check: film -> inventory -> rental
-- LEFT JOIN keeps films even with no inventory or rental match
-- WHERE r.rental_id IS NULL isolates films with no rental record

SELECT f.film_id,
       f.title
FROM   film f
LEFT JOIN inventory i ON f.film_id = i.film_id
LEFT JOIN rental r    ON i.inventory_id = r.inventory_id
WHERE  r.rental_id IS NULL;

-- Alternative using subquery (same result):
SELECT title
FROM   film
WHERE  film_id NOT IN (
    SELECT DISTINCT f.film_id
    FROM   film f
    JOIN   inventory i ON f.film_id = i.film_id
    JOIN   rental r    ON i.inventory_id = r.inventory_id
);

-- ============================================================
--  QUICK CONCEPT SUMMARY
-- ============================================================
--
--  WHERE    → filters rows BEFORE GROUP BY
--  HAVING   → filters groups AFTER GROUP BY (use with COUNT/AVG/SUM)
--  IS NULL  → always use this to check for null, NEVER = NULL
--  LEFT JOIN→ keeps all rows from left table even with no match
--  LIKE '%x'→ x can appear anywhere in string
--  IN(a,b)  → cleaner than writing OR multiple times
--  DISTINCT → removes duplicate values from output
--  DESC     → highest first in ORDER BY
--  LIMIT n  → return only n rows
--
-- ============================================================
